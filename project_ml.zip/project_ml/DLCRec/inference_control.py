import sys
import fire
import gradio as gr
import torch
torch.set_num_threads(1)
import transformers
import json
import os
import re
from peft import PeftModel
from transformers import GenerationConfig, AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm

# === NEW: QRNCA import and function ===
QRNCA_JSON_PATH = "./data/movie_sgcate/neurons_by_genre.json"  # path to your QRNCA neurons file

def postprocess_genres_with_qrnca(history_genres, gp_output_genres, genre_neuron_json):
    """
    history_genres: list of genres from user history (ideally strings like 'Comedy', 'Drama')
    gp_output_genres: genres predicted by DLCRec GP (parsed as list of strings)
    genre_neuron_json: dict {genre: [[layer, neuron], ...]} from neurons_by_genre.json

    Returns: a new list of genres (same length as gp_output_genres)
             built using neuron overlap, so it can differ from DLCRec.
    """

    # 0. Build neuron sets: N[genre] = set of (layer, neuron)
    N = {g: set(tuple(x) for x in neurons) for g, neurons in genre_neuron_json.items()}

    # 1. Clean history and GP genres to those that exist in neuron_json
    H_raw = [g for g in history_genres if isinstance(g, str)]
    Gp_raw = [g for g in gp_output_genres if isinstance(g, str)]

    H = [g for g in H_raw if g in N]
    if not H:
        # Fallback: if history genres don’t match neuron keys,
        # use GP genres as pseudo-history to still get some signal.
        H = [g for g in Gp_raw if g in N]

    if not H:
        # Still nothing? Then we cannot use neurons; just return original.
        return Gp_raw if Gp_raw else gp_output_genres

    # 2. Build history neuron pool N_H
    N_H = set()
    for g in H:
        N_H |= N[g]

    N_c = len(Gp_raw) if Gp_raw else len(gp_output_genres)
    if N_c == 0:
        return Gp_raw

    # 3. Decide how many history genres to keep explicitly
    #    (e.g., at most 1/3 of the control number, but at least 1)
    H_unique = list(dict.fromkeys(H))  # preserve order, deduplicate
    k_hist_keep = max(1, min(len(H_unique), N_c // 3))

    # 4. Candidate diverse genres = all genres with neurons that are not in kept-history
    kept_history = H_unique[:k_hist_keep]
    kept_history_set = set(kept_history)

    candidates = [g for g in N.keys() if g not in kept_history_set]

    # 5. Score candidates by neuron overlap with history neuron pool
    def score(g):
        inter = N[g] & N_H
        return len(inter)

    candidates_scored = sorted(candidates, key=score, reverse=True)

    k_div = N_c - k_hist_keep
    if k_div <= 0:
        return kept_history[:N_c]

    G_div_qr = candidates_scored[:k_div]

    # 6. Final genre list: some history + QRNCA-chosen others
    G_final = kept_history + G_div_qr
    return G_final




if torch.cuda.is_available():
    device = "cuda"
else:
    device = "cpu"
try:
    if torch.backends.mps.is_available():
        device = "mps"
except:
    pass
print("device is", device)

def main(
    load_8bit: bool = False,
    base_model: str = "",
    lora_weights: str = "tloen/alpaca-lora-7b",
    test_data_path: str = "data/test.json",
    result_json_data: str = "temp.json",
    control_GPnum: int = 0,
    batch_size: int = 16,
    num_beams: int = 1,
    num_beam_groups: int = 1,
    do_sample: bool = False,
):
    assert base_model, "Please specify --base_model"

    tokenizer = AutoTokenizer.from_pretrained(base_model)
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        load_in_8bit=load_8bit,
        torch_dtype=torch.float16 if device == "cuda" else torch.float32,
        device_map="auto" if device == "cuda" else None,
    )
    if lora_weights:
        model = PeftModel.from_pretrained(model, lora_weights, torch_dtype=torch.float16 if device == "cuda" else torch.float32)

    tokenizer.padding_side = "left"
    model.config.pad_token_id = tokenizer.pad_token_id = 0
    model.config.bos_token_id = 1
    model.config.eos_token_id = 2
    terminators = [tokenizer.eos_token_id, tokenizer.convert_tokens_to_ids("<|eot_id|>")]
    if not load_8bit:
        model.half()
    model.eval()

    def evaluate(instructions, inputs=None, temperature=0.5, num_beams=num_beams, num_beam_groups=num_beam_groups, do_sample=do_sample, **kwargs):
        prompt = [generate_prompt(instr, inp) for instr, inp in zip(instructions, inputs)]
        inputs_enc = tokenizer(prompt, return_tensors="pt", padding=True, truncation=True).to(device)
        generation_config = GenerationConfig(num_beams=num_beams, num_beam_groups=num_beam_groups, do_sample=do_sample, **kwargs)
        with torch.no_grad():
            generation_output = model.generate(
                **inputs_enc,
                generation_config=generation_config,
                eos_token_id=terminators,
                return_dict_in_generate=True,
                output_scores=True,
                max_new_tokens=512,
            )
        s = generation_output.sequences
        output = tokenizer.batch_decode(s, skip_special_tokens=True)
        output = [_.split('Response:\n')[-1] for _ in output]
        return [output[i * num_beams:(i + 1) * num_beams] for i in range(len(output) // num_beams)]

    # === Load data ===
    with open(test_data_path, "r") as f:
        test_data = json.load(f)

    if control_GPnum == 0:
        instructions = [t["instruction"] for t in test_data]
    else:
        print(f"Control GP number: {control_GPnum}")
        instructions = instructions_control_GPnum(test_data, control_GPnum)
    inputs = [t["input"] for t in test_data]

    def batch(lst, bs=batch_size):
        for i in range(0, len(lst), bs):
            yield lst[i:i + bs]

    outputs = []
    for instr_batch, inp_batch in tqdm(zip(batch(instructions), batch(inputs))):
        out = evaluate(instr_batch, inp_batch)
        outputs += out

    # === QRNCA integration ===
    if os.path.exists(QRNCA_JSON_PATH):
        with open(QRNCA_JSON_PATH, "r") as f:
            genre_neuron_json = json.load(f)
    else:
        print(f"⚠️ QRNCA neuron file not found: {QRNCA_JSON_PATH}")
        genre_neuron_json = {}

    for i, test in enumerate(test_data):
        pred = outputs[i][0] if isinstance(outputs[i], list) else outputs[i]
        test["predict_original"] = pred
        try:
            pred_list = [g.strip() for g in re.split(r"[,|]", pred) if g.strip()]
        except Exception:
            pred_list = [pred]
        history_genres = test.get("his_cate", [])  # adjust if your key differs
        test["predict_qrnca"] = postprocess_genres_with_qrnca(history_genres, pred_list, genre_neuron_json)

    # === Save both outputs ===
    with open(result_json_data.replace(".json", "_QRNCA.json"), "w") as f:
        json.dump(test_data, f, indent=4)
    print(f"✅ Saved QRNCA output to {result_json_data.replace('.json','_QRNCA.json')}")


def generate_prompt(instruction, input=None):
    if input:
        return f"""Below is an instruction that describes a task, paired with an input that provides further context. Write a response that appropriately completes the request.  

### Instruction:
{instruction}

### Input:
{input}

### Response:
"""
    else:
        return f"""Below is an instruction that describes a task. Write a response that appropriately completes the request.  

### Instruction:
{instruction}

### Response:
"""

def instructions_control_GPnum(test_data, control_GPnum):
    pattern1 = r"the (\d+) most likely genres"
    pattern2 = r"Genre1, Genre2, ..., Genre(.*?)\""
    pattern3 = r"Genre1\| Genre2\| ...\| Genre(.*?)\""
    ins1 = [re.sub(pattern1, f"the {control_GPnum} most likely genres", td["instruction"]) for td in test_data]
    ins2 = [re.sub(pattern2, f"Genre1, Genre2, ..., Genre{control_GPnum}\"", ins) for ins in ins1]
    return [re.sub(pattern3, f"Genre1| Genre2| ...| Genre{control_GPnum}\"", ins) for ins in ins2]

if __name__ == "__main__":
    fire.Fire(main)
