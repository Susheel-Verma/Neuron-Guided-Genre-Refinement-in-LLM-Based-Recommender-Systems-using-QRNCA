from ._extract_key_neuron import NaicaKeyNeuron as KeyNeuron

__all__ = [
    KeyNeuron
]